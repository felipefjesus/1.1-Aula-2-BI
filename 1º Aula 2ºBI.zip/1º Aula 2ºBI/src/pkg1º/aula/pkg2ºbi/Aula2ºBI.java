/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg1º.aula.pkg2ºbi;

/**
 *
 * @author felipe.fjesus1
 */
public class Aula2ºBI {
    public static void frase(){
        System.out.println("Imprimindo uma função");
     
    }
    public static void flor(){
        System.out.println("Rosa");
        
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         frase();
         flor();
         flor(2);
         
    }
    
}
